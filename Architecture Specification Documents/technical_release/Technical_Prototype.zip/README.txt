Mouse controls: Oob will rotate to face the current location of the mouse. Left click to jump off of a planet.

Keyboard controls: left arrow to rotate counter-clockwise and right arrow to rotate clockwise. Space to jump off of a planet.

Controls start in mouse mode by default. Press m to switch between control schemes.

Press R to reset the level.

Press P to pause the level.